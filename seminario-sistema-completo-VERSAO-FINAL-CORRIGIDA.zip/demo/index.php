<?php
/**
 * Demo page for II Seminário Internacional Pró-Reparações Plugin
 * This demonstrates the plugin functionality without requiring full WordPress installation
 */

// Basic error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Simulate some WordPress functions that the plugin uses
if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field($str) {
        return htmlspecialchars(strip_tags($str), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('sanitize_email')) {
    function sanitize_email($email) {
        return filter_var($email, FILTER_SANITIZE_EMAIL);
    }
}

if (!function_exists('is_email')) {
    function is_email($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

if (!function_exists('esc_html')) {
    function esc_html($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('esc_attr')) {
    function esc_attr($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('esc_url')) {
    function esc_url($url) {
        return htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    }
}

// Get request path and page parameter
$request = $_SERVER['REQUEST_URI'];
$path = parse_url($request, PHP_URL_PATH);
$page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'home';
$admin = $_GET['admin'] ?? false;

// Se está acessando o admin, redirecionar para o arquivo admin
if ($admin) {
    include 'admin.php';
    exit;
}

// Debug - remove this line in production
// echo "<!-- DEBUG: Current page = '$page', GET = " . print_r($_GET, true) . " -->";

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>II Seminário Internacional Pró-Reparações - Sistema Completo</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <header style="text-align: center; padding: 40px 20px; background: #2271b1; color: white; margin-bottom: 40px;">
            <h1>II Seminário Internacional Pró-Reparações</h1>
            <h2 style="font-weight: normal; margin-top: 10px;">Um Projeto de Nação</h2>
            <p style="margin-top: 20px; font-size: 18px;">10-14 de Novembro de 2025 | Belo Horizonte - MG</p>
        </header>

        <main style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
            <?php if ($page === 'home'): ?>
            <div style="background: #f8f9fa; border: 1px solid #e1e1e1; border-radius: 8px; padding: 30px; margin-bottom: 40px;">
                <h2>Bem-vindo ao Sistema de Gestão do Seminário</h2>
                <p>Este é um sistema completo de gestão para o II Seminário Internacional Pró-Reparações, desenvolvido como plugin WordPress.</p>
                
                <div style="margin: 30px 0;">
                    <h3>🎯 Funcionalidades Principais:</h3>
                    <ul style="line-height: 1.8; margin-left: 20px;">
                        <li><strong>Painel Administrativo</strong> - Dashboard com estatísticas reais (22 conferencistas, 15 observadores)</li>
                        <li><strong>Gestão de Inscrições</strong> - CRUD completo com busca e filtros</li>
                        <li><strong>Painéis Temáticos</strong> - 6 painéis oficiais com palestrantes confirmados</li>
                        <li><strong>Conferencistas</strong> - Biografias autênticas das autoridades participantes</li>
                        <li><strong>Observadores Internacionais</strong> - Acadêmicos de 8 países</li>
                        <li><strong>Formulários Responsivos</strong> - Interface moderna afro-brasileira</li>
                    </ul>
                </div>

                <div style="margin: 30px 0;">
                    <h3>📊 Painéis Temáticos (Dados Reais):</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 20px; margin: 20px 0;">
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px;">
                            <h4 style="color: #2271b1; margin-top: 0;">Estatuto da Igualdade Racial - MG</h4>
                            <p><strong>Data:</strong> 10/11/2025 - 13:20 às 14:50</p>
                            <p><strong>Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                            <p>Com Ministras Macaé Evaristo e Anielle Franco</p>
                        </div>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px;">
                            <h4 style="color: #2271b1; margin-top: 0;">Reparações e justiça fiscal</h4>
                            <p><strong>Data:</strong> 10/11/2025 - 15:00 às 17:30</p>
                            <p><strong>Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                            <p>Enfrentando o neocolonialismo nas reparações</p>
                        </div>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px;">
                            <h4 style="color: #2271b1; margin-top: 0;">Soberania digital</h4>
                            <p><strong>Data:</strong> 11/11/2025 - 13:30 às 15:30</p>
                            <p><strong>Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                            <p>Comunicação e combate ao racismo cibernético</p>
                        </div>
                    </div>
                </div>

                <div style="margin: 30px 0;">
                    <h3>🎤 Conferencistas Confirmados:</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 15px; margin: 20px 0;">
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px;">
                            <h4 style="margin-top: 0; color: #333;">Anielle Franco</h4>
                            <p style="color: #2271b1; font-weight: bold; margin: 5px 0;">Ministra da Igualdade Racial</p>
                            <p style="color: #666; font-size: 14px;">Brasil</p>
                        </div>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px;">
                            <h4 style="margin-top: 0; color: #333;">Macaé Evaristo</h4>
                            <p style="color: #2271b1; font-weight: bold; margin: 5px 0;">Ministra dos Direitos Humanos</p>
                            <p style="color: #666; font-size: 14px;">Brasil</p>
                        </div>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px;">
                            <h4 style="margin-top: 0; color: #333;">Mireille Fanon Mendès-France</h4>
                            <p style="color: #2271b1; font-weight: bold; margin: 5px 0;">Presidente da Fundação Frantz Fanon</p>
                            <p style="color: #666; font-size: 14px;">França</p>
                        </div>
                    </div>
                </div>

                <div style="margin: 30px 0;">
                    <h3>👁️ Observadores Internacionais:</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 15px; margin: 20px 0;">
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px;">
                            <h4 style="margin-top: 0; color: #333;">Angela Davis</h4>
                            <p style="color: #2271b1; font-weight: bold; margin: 5px 0;">Professora Emérita</p>
                            <p style="color: #666; font-size: 14px;">Universidade da Califórnia - EUA</p>
                        </div>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px;">
                            <h4 style="margin-top: 0; color: #333;">Achille Mbembe</h4>
                            <p style="color: #2271b1; font-weight: bold; margin: 5px 0;">Professor e Filósofo</p>
                            <p style="color: #666; font-size: 14px;">Universidade de Witwatersrand - África do Sul</p>
                        </div>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px;">
                            <h4 style="margin-top: 0; color: #333;">Kimberlé Crenshaw</h4>
                            <p style="color: #2271b1; font-weight: bold; margin: 5px 0;">Professora de Direito</p>
                            <p style="color: #666; font-size: 14px;">Columbia e UCLA - EUA</p>
                        </div>
                    </div>
                </div>

                <div style="margin: 40px 0; text-align: center;">
                    <h3>🔍 Teste o Sistema Sem Instalar!</h3>
                    <p style="margin: 20px 0; font-size: 16px;">Navegue pelas páginas demo para ver todas as funcionalidades:</p>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 30px 0;">
                        <a href="?page=inscricao" style="background: linear-gradient(135deg, #FF6B35, #D63031); color: white; padding: 15px; border-radius: 8px; text-decoration: none; display: block; transition: transform 0.2s;">
                            📝 Formulário de Inscrição
                        </a>
                        <a href="?page=paineis" style="background: linear-gradient(135deg, #FDCB6E, #FF6B35); color: white; padding: 15px; border-radius: 8px; text-decoration: none; display: block; transition: transform 0.2s;">
                            🎯 Painéis Temáticos
                        </a>
                        <a href="?page=conferencistas" style="background: linear-gradient(135deg, #00B894, #FDCB6E); color: white; padding: 15px; border-radius: 8px; text-decoration: none; display: block; transition: transform 0.2s;">
                            🎤 Conferencistas
                        </a>
                        <a href="?page=observadores" style="background: linear-gradient(135deg, #6C5CE7, #00B894); color: white; padding: 15px; border-radius: 8px; text-decoration: none; display: block; transition: transform 0.2s;">
                            👁️ Observadores
                        </a>
                        <a href="?admin=1" style="background: linear-gradient(135deg, #28a745, #20c997); color: white; padding: 15px; border-radius: 8px; text-decoration: none; display: block; transition: transform 0.2s; font-weight: bold; border: 2px solid rgba(255,255,255,0.3);">
                            🔧 Área Administrativa
                        </a>
                    </div>
                    <p style="background: #e3f2fd; border: 1px solid #2196f3; border-radius: 8px; padding: 15px; margin: 20px 0;">
                        <strong>💡 Dica:</strong> Clique nos links acima para ver a interface afro moderna em ação!
                    </p>
                </div>

                <div style="margin: 40px 0; text-align: center;">
                    <h3>🔧 Shortcodes WordPress Disponíveis:</h3>
                    <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; text-align: left;">
                        <p><code style="background: #f1f1f1; padding: 4px 8px; border-radius: 4px;">[seminario_inscricao]</code> - Formulário de inscrição completo</p>
                        <p><code style="background: #f1f1f1; padding: 4px 8px; border-radius: 4px;">[seminario_paineis]</code> - Lista de painéis temáticos</p>
                        <p><code style="background: #f1f1f1; padding: 4px 8px; border-radius: 4px;">[seminario_conferencistas]</code> - Lista de conferencistas</p>
                        <p><code style="background: #f1f1f1; padding: 4px 8px; border-radius: 4px;">[seminario_observadores]</code> - Lista de observadores</p>
                    </div>
                </div>

                <div style="margin: 40px 0; text-align: center;">
                    <h3>💾 Estrutura de Dados:</h3>
                    <p>O plugin cria 5 tabelas no banco de dados com dados reais integrados:</p>
                    <ul style="text-align: left; max-width: 600px; margin: 20px auto; line-height: 1.6;">
                        <li><code>wp_seminario_inscricoes</code> - Sistema de inscrições ativo</li>
                        <li><code>wp_seminario_paineis</code> - 6 painéis oficiais programados</li>
                        <li><code>wp_seminario_conferencistas</code> - 22 conferencistas confirmados</li>
                        <li><code>wp_seminario_observadores</code> - 15 observadores internacionais</li>
                        <li><code>wp_seminario_configuracoes</code> - Configurações do evento</li>
                    </ul>
                </div>
            </div>

            <div style="background: #2271b1; color: white; border-radius: 8px; padding: 30px; text-align: center; margin-bottom: 40px;">
                <h2 style="margin-top: 0;">🚀 Plugin WordPress Pronto para Uso</h2>
                <p style="font-size: 18px; margin-bottom: 25px;">Sistema completo com dados reais dos documentos oficiais</p>
                
                <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap; margin-bottom: 25px;">
                    <a href="seminario-sistema-completo-dados-reais.zip" style="background: #FF6B35; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: bold; display: inline-block;">
                        📦 Baixar Plugin (.zip)
                    </a>
                    <a href="?admin=1" style="background: #28a745; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: bold; display: inline-block;">
                        🔧 Testar Área Admin
                    </a>
                    <a href="INSTALACAO.md" style="background: rgba(255,255,255,0.2); color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; display: inline-block;">
                        📖 Guia de Instalação
                    </a>
                </div>
                
                <div style="margin-top: 30px;">
                    <strong>Tecnologias utilizadas:</strong><br>
                    PHP • JavaScript (jQuery) • CSS3 • MySQL/PostgreSQL • WordPress APIs
                </div>
            </div>
            <?php else: ?>
            <!-- Navegação entre páginas -->
            <div style="background: linear-gradient(135deg, #FF6B35, #D63031); padding: 20px; border-radius: 8px; margin-bottom: 30px; text-align: center;">
                <h1 style="color: white; margin: 0; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
                    <?php 
                    switch($page) {
                        case 'inscricao': echo '📝 Formulário de Inscrição'; break;
                        case 'paineis': echo '🎯 Painéis Temáticos'; break;
                        case 'conferencistas': echo '🎤 Conferencistas'; break;
                        case 'observadores': echo '👁️ Observadores Internacionais'; break;
                        default: echo '🌟 Sistema de Gestão';
                    }
                    ?>
                </h1>
                <div style="margin-top: 15px;">
                    <a href="?" style="background: rgba(255,255,255,0.2); color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; margin: 0 5px;">🏠 Início</a>
                    <a href="?page=inscricao" style="background: rgba(255,255,255,0.2); color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; margin: 0 5px;">📝 Inscrição</a>
                    <a href="?page=paineis" style="background: rgba(255,255,255,0.2); color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; margin: 0 5px;">🎯 Painéis</a>
                    <a href="?page=conferencistas" style="background: rgba(255,255,255,0.2); color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; margin: 0 5px;">🎤 Palestrantes</a>
                    <a href="?page=observadores" style="background: rgba(255,255,255,0.2); color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; margin: 0 5px;">👁️ Observadores</a>
                </div>
            </div>
            
            <div style="background: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 40px;">
                <?php
                // Carregar conteúdo da página específica
                $page_file = __DIR__ . '/pages/' . $page . '.php';
                if (file_exists($page_file)) {
                    include $page_file;
                } else {
                    echo '<h2>❌ Página não encontrada</h2>';
                    echo '<p>A página solicitada não existe. <a href="?">Voltar ao início</a></p>';
                }
                ?>
            </div>
            <?php endif; ?>
        </main>

        <footer style="text-align: center; padding: 40px 20px; background: #f0f0f0; margin-top: 60px; color: #666;">
            <p><strong>Organização:</strong> Coletivo Minas Pró-Reparações</p>
            <p><strong>Site:</strong> <a href="https://reparacoeshistoricas.org" style="color: #2271b1;">reparacoeshistoricas.org</a></p>
            <p style="margin-top: 20px;">Sistema desenvolvido para a causa das reparações históricas no Brasil 🇧🇷</p>
        </footer>
    </div>

    <script src="assets/script.js"></script>
</body>
</html>