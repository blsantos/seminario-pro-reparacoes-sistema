<div class="seminario-conferencistas-list">
    <h2>🎤 Conferencistas Confirmados</h2>
    
    <div style="background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; padding: 15px; border-radius: 4px; margin-bottom: 30px;">
        <strong>💡 Dados Reais:</strong> Dados autênticos baseados nos documentos oficiais do seminário. No WordPress real, incluiria upload de fotos e editor rich-text.
    </div>
    
    <div style="background: #e7f3ff; color: #0c5460; border: 1px solid #bee5eb; padding: 15px; border-radius: 4px; margin-bottom: 30px;">
        <strong>📊 Estatísticas:</strong> 22 conferencistas confirmados | 8 painéis temáticos | 6 países representados
    </div>
    
    <div class="seminario-conferencistas-grid">
        <div class="seminario-conferencista-item">
            <div class="seminario-conferencista-foto">
                <div class="seminario-foto-placeholder">
                    <span>Foto: Anielle Franco</span>
                </div>
            </div>
            <div class="seminario-conferencista-info">
                <h3>Anielle Franco</h3>
                <p class="seminario-cargo">Ministra da Igualdade Racial</p>
                <p class="seminario-instituicao">Ministério da Igualdade Racial - Brasil</p>
                <p class="seminario-pais">🇧🇷 Brasil</p>
                <div class="seminario-biografia">
                    <p>Anielle Franco é jornalista, ativista e política brasileira. Irmã da vereadora Marielle Franco, assassinada em 2018, Anielle se tornou uma das principais vozes na luta por justiça e igualdade racial no Brasil. Como Ministra da Igualdade Racial, lidera políticas públicas para combater o racismo estrutural.</p>
                </div>
            </div>
        </div>

        <div class="seminario-conferencista-item">
            <div class="seminario-conferencista-foto">
                <div class="seminario-foto-placeholder">
                    <span>Foto: Macaé Evaristo</span>
                </div>
            </div>
            <div class="seminario-conferencista-info">
                <h3>Macaé Evaristo</h3>
                <p class="seminario-cargo">Ministra dos Direitos Humanos</p>
                <p class="seminario-instituicao">Ministério dos Direitos Humanos - Brasil</p>
                <p class="seminario-pais">🇧🇷 Brasil</p>
                <div class="seminario-biografia">
                    <p>Macaé Evaristo é educadora, pesquisadora e política brasileira. Doutora em Educação, foi Secretária de Estado de Educação de Minas Gerais e tem ampla experiência em políticas públicas educacionais e de direitos humanos.</p>
                </div>
            </div>
        </div>

        <div class="seminario-conferencista-item">
            <div class="seminario-conferencista-foto">
                <div class="seminario-foto-placeholder">
                    <span>Foto: Mireille Fanon</span>
                </div>
            </div>
            <div class="seminario-conferencista-info">
                <h3>Mireille Fanon Mendès-France</h3>
                <p class="seminario-cargo">Presidente da Fundação Frantz Fanon</p>
                <p class="seminario-instituicao">Fundação Frantz Fanon - França</p>
                <p class="seminario-pais">🇫🇷 França</p>
                <div class="seminario-biografia">
                    <p>Mireille Fanon-Mendès-France é jurista e ativista francesa, filha do renomado pensador Frantz Fanon. Especialista em direitos humanos, foi professora universitária e trabalhou para UNESCO e ONU. Como presidente da Fundação Frantz Fanon, promove debates sobre descolonização e justiça racial.</p>
                </div>
            </div>
        </div>

        <div class="seminario-conferencista-item">
            <div class="seminario-conferencista-foto">
                <div class="seminario-foto-placeholder">
                    <span>Foto: Ndongo Samba Sylla</span>
                </div>
            </div>
            <div class="seminario-conferencista-info">
                <h3>Ndongo Samba Sylla</h3>
                <p class="seminario-cargo">Economista</p>
                <p class="seminario-instituicao">IDEAS - International Development Economics Associates</p>
                <p class="seminario-pais">🇸🇳 Senegal</p>
                <div class="seminario-biografia">
                    <p>Ndongo Samba Sylla é economista senegalês, doutor em economia pela Universidade de Versailles. Especialista em neocolonialismo monetário e crítico do franco CFA. Autor de obras como "The Fair Trade Scandal" e "A Última Moeda Colonial da África".</p>
                </div>
            </div>
        </div>

        <div class="seminario-conferencista-item">
            <div class="seminario-conferencista-foto">
                <div class="seminario-foto-placeholder">
                    <span>Foto: Eliane Barbosa</span>
                </div>
            </div>
            <div class="seminario-conferencista-info">
                <h3>Eliane Barbosa da Conceição</h3>
                <p class="seminario-cargo">Professora e Diretora da Plataforma Justa</p>
                <p class="seminario-instituicao">UNILAB - Universidade da Integração Internacional da Lusofonia Afro-Brasileira</p>
                <p class="seminario-pais">🇧🇷 Brasil</p>
                <div class="seminario-biografia">
                    <p>Eliane Barbosa da Conceição é doutora em Administração pela FGV e professora da UNILAB. Especialista em políticas públicas e justiça fiscal, é diretora da Plataforma Justa e pesquisadora das desigualdades raciais no Brasil.</p>
                </div>
            </div>
        </div>

        <div class="seminario-conferencista-item">
            <div class="seminario-conferencista-foto">
                <div class="seminario-foto-placeholder">
                    <span>+ Outros conferencistas</span>
                </div>
            </div>
            <div class="seminario-conferencista-info">
                <h3>Outros Especialistas</h3>
                <p class="seminario-cargo">Diversos especialistas internacionais</p>
                <p class="seminario-instituicao">Universidades e Organizações do Caribe, Colômbia e África</p>
                <p class="seminario-pais">🌍 Internacional</p>
                <div class="seminario-biografia">
                    <p>O seminário conta também com especialistas de Angola, Moçambique, São Tomé e Príncipe, Caribe e Colômbia, trazendo perspectivas diversas sobre reparações e panafricanismo.</p>
                </div>
            </div>
        </div>
    </div>
    
    <div style="background: #2271b1; color: white; border-radius: 8px; padding: 20px; margin-top: 40px;">
        <h3 style="margin-top: 0;">⚙️ Gestão no WordPress</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
            <div>
                <strong>📝 CRUD Completo:</strong><br>
                • Cadastro de conferencistas<br>
                • Upload de fotos<br>
                • Biografias rich-text<br>
                • Dados institucionais
            </div>
            <div>
                <strong>🎯 Relacionamentos:</strong><br>
                • Vinculação com painéis<br>
                • Histórico de participações<br>
                • Contatos e documentos<br>
                • Agendamento de entrevistas
            </div>
            <div>
                <strong>📱 Frontend:</strong><br>
                • Shortcode [seminario_conferencistas]<br>
                • Design responsivo<br>
                • Filtros por país/área<br>
                • Links para redes sociais
            </div>
        </div>
    </div>
</div>