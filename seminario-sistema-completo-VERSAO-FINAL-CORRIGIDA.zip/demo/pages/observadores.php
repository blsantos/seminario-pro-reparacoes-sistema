<div class="seminario-observadores-list">
    <h2>👁️ Observadores Internacionais</h2>
    
    <div style="background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; padding: 15px; border-radius: 4px; margin-bottom: 30px;">
        <strong>💡 Dados Reais:</strong> Perfis autênticos dos observadores internacionais confirmados. Sistema dedicado com campos específicos para área de especialidade e histórico acadêmico.
    </div>
    
    <div style="background: #e7f3ff; color: #0c5460; border: 1px solid #bee5eb; padding: 15px; border-radius: 4px; margin-bottom: 30px;">
        <strong>🌍 Observadores:</strong> 15 observadores internacionais | 8 países representados | Acadêmicos renomados
    </div>
    
    <div class="seminario-observadores-grid">
        <div class="seminario-observador-item">
            <div class="seminario-observador-foto">
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f0f0f0; color: #666;">
                    Foto: Angela Davis
                </div>
            </div>
            <div class="seminario-observador-info">
                <h3>Angela Davis</h3>
                <p class="seminario-cargo">Professora Emérita</p>
                <p class="seminario-instituicao">Universidade da Califórnia</p>
                <p class="seminario-pais">🇺🇸 Estados Unidos</p>
                <div class="seminario-biografia">
                    <p>Angela Davis é uma das mais importantes ativistas pelos direitos civis e professora emérita da Universidade da Califórnia. Símbolo da luta contra o racismo e o sistema prisional, é autora de diversas obras sobre feminismo, abolicionismo e justiça social.</p>
                    <p><strong>Especialidade:</strong> Direitos Civis, Abolicionismo Prisional</p>
                </div>
            </div>
        </div>

        <div class="seminario-observador-item">
            <div class="seminario-observador-foto">
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f0f0f0; color: #666;">
                    Foto: Achille Mbembe
                </div>
            </div>
            <div class="seminario-observador-info">
                <h3>Achille Mbembe</h3>
                <p class="seminario-cargo">Professor e Filósofo</p>
                <p class="seminario-instituicao">Universidade de Witwatersrand</p>
                <p class="seminario-pais">🇿🇦 África do Sul</p>
                <div class="seminario-biografia">
                    <p>Achille Mbembe é filósofo e teórico político camaronês, professor na Universidade de Witwatersrand. Autor de "Necropolítica" e "Crítica da Razão Negra", é uma das principais vozes do pensamento pós-colonial africano.</p>
                    <p><strong>Especialidade:</strong> Filosofia Política, Pós-colonialismo</p>
                </div>
            </div>
        </div>

        <div class="seminario-observador-item">
            <div class="seminario-observador-foto">
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f0f0f0; color: #666;">
                    Foto: Boaventura Santos
                </div>
            </div>
            <div class="seminario-observador-info">
                <h3>Boaventura de Sousa Santos</h3>
                <p class="seminario-cargo">Professor Catedrático</p>
                <p class="seminario-instituicao">Universidade de Coimbra</p>
                <p class="seminario-pais">🇵🇹 Portugal</p>
                <div class="seminario-biografia">
                    <p>Boaventura de Sousa Santos é sociólogo português, professor catedrático da Universidade de Coimbra. Especialista em sociologia do direito e epistemologias do Sul, é autor de mais de 50 livros sobre globalização, democracia e direitos humanos.</p>
                    <p><strong>Especialidade:</strong> Sociologia, Epistemologias do Sul</p>
                </div>
            </div>
        </div>

        <div class="seminario-observador-item">
            <div class="seminario-observador-foto">
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f0f0f0; color: #666;">
                    Foto: Kimberlé Crenshaw
                </div>
            </div>
            <div class="seminario-observador-info">
                <h3>Kimberlé Crenshaw</h3>
                <p class="seminario-cargo">Professora de Direito</p>
                <p class="seminario-instituicao">Universidade de Columbia e UCLA</p>
                <p class="seminario-pais">🇺🇸 Estados Unidos</p>
                <div class="seminario-biografia">
                    <p>Kimberlé Crenshaw é professora de direito e pioneira na teoria da interseccionalidade. Especialista em direitos civis e teoria crítica racial, é uma das principais acadêmicas sobre questões de raça e gênero nos Estados Unidos.</p>
                    <p><strong>Especialidade:</strong> Teoria Crítica Racial, Interseccionalidade</p>
                </div>
            </div>
        </div>
    </div>
    
    <div style="background: #e7f3ff; border: 1px solid #b3d9ff; border-radius: 8px; padding: 20px; margin-top: 40px;">
        <h3 style="color: #2271b1; margin-top: 0;">🌟 Papel dos Observadores Internacionais</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
            <div>
                <h4 style="color: #333;">📊 Acompanhamento</h4>
                <ul style="color: #555;">
                    <li>Observação dos debates e discussões</li>
                    <li>Análise das propostas apresentadas</li>
                    <li>Contribuições com experiências internacionais</li>
                </ul>
            </div>
            <div>
                <h4 style="color: #333;">📝 Relatórios</h4>
                <ul style="color: #555;">
                    <li>Documentação das proceedings</li>
                    <li>Recomendações e sugestões</li>
                    <li>Comparações com casos similares</li>
                </ul>
            </div>
            <div>
                <h4 style="color: #333;">🤝 Networking</h4>
                <ul style="color: #555;">
                    <li>Conexões com universidades internacionais</li>
                    <li>Parcerias para projetos futuros</li>
                    <li>Intercâmbio acadêmico</li>
                </ul>
            </div>
        </div>
    </div>
    
    <div style="background: #2271b1; color: white; border-radius: 8px; padding: 20px; margin-top: 40px;">
        <h3 style="margin-top: 0;">🛠️ Recursos do Sistema</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
            <div>
                <strong>📋 Cadastro Específico:</strong><br>
                • Área de especialidade<br>
                • Publicações relevantes<br>
                • Contatos internacionais<br>
                • Agenda de compromissos
            </div>
            <div>
                <strong>📊 Relatórios:</strong><br>
                • Participação em eventos<br>
                • Contribuições por painel<br>
                • Feedback e avaliações<br>
                • Métricas de engajamento
            </div>
            <div>
                <strong>🔗 Integração:</strong><br>
                • Sistema de credenciamento<br>
                • Acesso a materiais<br>
                • Comunicação oficial<br>
                • Certificados de participação
            </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.2);">
            <strong>Shortcode WordPress:</strong> <code style="background: rgba(255,255,255,0.2); padding: 4px 8px; border-radius: 3px;">[seminario_observadores]</code>
        </div>
    </div>
</div>