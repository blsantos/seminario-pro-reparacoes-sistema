<div style="background: #f8f9fa; border: 1px solid #e1e1e1; border-radius: 8px; padding: 30px; margin-bottom: 40px;">
    <h2>🧪 Ambiente de Teste - Sistema Completo</h2>
    <p>Teste todas as funcionalidades do plugin aqui antes de instalar no WordPress!</p>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 30px 0;">
        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; text-align: center;">
            <h3 style="color: #2271b1; margin-top: 0;">📝 Formulário de Inscrição</h3>
            <p>Teste o formulário completo com validação</p>
            <a href="/inscricao" style="display: inline-block; background: #2271b1; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 10px;">Testar Inscrição</a>
        </div>
        
        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; text-align: center;">
            <h3 style="color: #2271b1; margin-top: 0;">🎯 Painéis Temáticos</h3>
            <p>Veja todos os 6 painéis do seminário</p>
            <a href="/paineis" style="display: inline-block; background: #2271b1; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 10px;">Ver Painéis</a>
        </div>
        
        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; text-align: center;">
            <h3 style="color: #2271b1; margin-top: 0;">🎤 Conferencistas</h3>
            <p>Ministras e especialistas confirmados</p>
            <a href="/conferencistas" style="display: inline-block; background: #2271b1; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 10px;">Ver Conferencistas</a>
        </div>
        
        <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; text-align: center;">
            <h3 style="color: #2271b1; margin-top: 0;">👁️ Observadores</h3>
            <p>Personalidades internacionais</p>
            <a href="/observadores" style="display: inline-block; background: #2271b1; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 10px;">Ver Observadores</a>
        </div>
    </div>
    
    <div style="background: #2271b1; color: white; border-radius: 8px; padding: 20px; margin-top: 30px;">
        <h3 style="margin-top: 0;">✅ Dados Reais Incluídos:</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div>
                <ul style="margin: 0; padding-left: 20px;">
                    <li><strong>6 Painéis temáticos</strong> com cronograma real</li>
                    <li><strong>9 Conferencistas</strong> confirmados (Ministras, especialistas internacionais)</li>
                    <li><strong>8 Observadores</strong> internacionais renomados</li>
                    <li><strong>Orçamento</strong>: R$ 829.500,00</li>
                </ul>
            </div>
            <div>
                <ul style="margin: 0; padding-left: 20px;">
                    <li><strong>Contexto ancestral:</strong> 330 anos de Zumbi</li>
                    <li><strong>Datas:</strong> 10-14 de Novembro de 2025</li>
                    <li><strong>Local:</strong> BH - ALMG e UFMG</li>
                    <li><strong>Site:</strong> reparacoeshistoricas.org</li>
                </ul>
            </div>
        </div>
        
        <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 5px; margin-top: 20px; text-align: center;">
            <strong>📦 PLUGIN PRONTO PARA DOWNLOAD!</strong><br>
            <small>Arquivo: seminario-sistema-completo.tar.gz (14KB)</small>
        </div>
    </div>
</div>