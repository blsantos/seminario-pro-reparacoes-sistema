<div class="seminario-paineis-list">
    <h2>🎯 Painéis Temáticos do Seminário</h2>
    
    <div style="background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; padding: 15px; border-radius: 4px; margin-bottom: 30px;">
        <strong>💡 Dados Reais:</strong> Programação oficial do seminário com horários confirmados e palestrantes definidos. Sistema completo de gestão de painéis e controle de vagas.
    </div>
    
    <div style="background: #e7f3ff; color: #0c5460; border: 1px solid #bee5eb; padding: 15px; border-radius: 4px; margin-bottom: 30px;">
        <strong>📅 Programa:</strong> 6 painéis temáticos | 10-12 de Novembro de 2025 | 2 locais principais
    </div>
    
    <div class="seminario-paineis-grid">
        <div class="seminario-painel-item">
            <h3>Estatuto da Igualdade Racial no Estado de Minas Gerais</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 10/11/2025</p>
                <p><strong>🕒 Horário:</strong> 13:20 às 14:50</p>
                <p><strong>📍 Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                <p><strong>🎤 Palestrantes:</strong> Ministra Macaé Evaristo, Ministra Anielle Franco, Deputada Federal Dandara Tonantzin, Deputada Leninha Alves, Deputada Andreia de Jesus, Deputada Ana Paula Siqueira</p>
                <p><strong>👥 Mediador:</strong> Autoridades da ALMG</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Discussões sobre a Lei nº 25.150, de 14/01/2025, que institui o Estatuto da Igualdade Racial no Estado de Minas Gerais com participação das Ministras Macaé Evaristo e Anielle Franco.</p>
            </div>
        </div>
        
        <div class="seminario-painel-item">
            <h3>Reparações e justiça fiscal - o pagamento da dívida racial e o conserto dos elevadores quebrados</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 10/11/2025</p>
                <p><strong>🕒 Horário:</strong> 15:00 às 17:30</p>
                <p><strong>📍 Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                <p><strong>🎤 Palestrantes:</strong> Eliane Barbosa da Conceição, Mireille Fanon Mendès-France, Ndongo Samba Sylla</p>
                <p><strong>👥 Mediador:</strong> Douglas Belchior - Instituto Peregum</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Painel sobre reparações econômicas e justiça fiscal para a população negra, discutindo metodologias para cálculo da dívida racial e políticas de redistribuição.</p>
            </div>
        </div>

        <div class="seminario-painel-item">
            <h3>Reparações - Enfrentando o contexto internacional hostil do neocolonialismo</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 11/11/2025</p>
                <p><strong>🕒 Horário:</strong> 09:30 às 12:00</p>
                <p><strong>📍 Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                <p><strong>🎤 Palestrantes:</strong> Ndongo Samba Sylla, Koulsy Lamko, Marcelo d'Agostini</p>
                <p><strong>👥 Mediador:</strong> Maria da Consolação Rocha</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Análise do contexto internacional: guerras, ajustes estruturais, hiperimperialismo versus sinais promissores da multipolaridade e do Sul Global.</p>
            </div>
        </div>
        
        <div class="seminario-painel-item">
            <h3>A luta pró-reparações nos países credores: Portugal, Espanha e Inglaterra</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 11/11/2025</p>
                <p><strong>🕒 Horário:</strong> 13:40 às 15:00</p>
                <p><strong>📍 Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                <p><strong>🎤 Palestrantes:</strong> Luzia Moniz (Portugal), Conceição Queiroz (Portugal)</p>
                <p><strong>👥 Mediador:</strong> A definir</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Discussão sobre as estratégias de luta por reparações nos países europeus colonizadores, incluindo experiências e propostas de políticas.</p>
            </div>
        </div>

        <div class="seminario-painel-item">
            <h3>Reparações - Enfrentando o contexto hostil da comunicação, da soberania digital e do racismo cibernético</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 11/11/2025</p>
                <p><strong>🕒 Horário:</strong> 13:30 às 15:30</p>
                <p><strong>📍 Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                <p><strong>🎤 Palestrantes:</strong> Eliara Ferreira, Beto Almeida</p>
                <p><strong>👥 Mediador:</strong> Tatiana Carvalho Costa</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Discussão sobre comunicação, soberania digital e combate ao racismo online, abordando estratégias de resistência digital e democratização da comunicação.</p>
            </div>
        </div>

        <div class="seminario-painel-item">
            <h3>Reparações - Enfrentando o contexto hostil da perpetuação no poder das oligarquias via democracia eleitoral</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 11/11/2025</p>
                <p><strong>🕒 Horário:</strong> 16:00 às 18:00</p>
                <p><strong>📍 Local:</strong> Assembleia Legislativa de Minas Gerais</p>
                <p><strong>🎤 Palestrantes:</strong> Ndongo Samba Sylla, Ricardo Costa de Oliveira</p>
                <p><strong>👥 Mediador:</strong> A definir</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Análise sobre oligarquias e democracia no contexto das reparações, discutindo os obstáculos políticos e estruturais para implementação de políticas reparatórias.</p>
            </div>
        </div>

        <div class="seminario-painel-item">
            <h3>Panafricanismo e a luta pró-reparações no Caribe e na Colômbia: lições a tirar</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 12/11/2025</p>
                <p><strong>🕒 Horário:</strong> 09:30 às 12:00</p>
                <p><strong>📍 Local:</strong> Auditório da Faculdade de Engenharia da UFMG</p>
                <p><strong>🎤 Palestrantes:</strong> David Comissiong, Eric Phillips, Agustin Lao-Montes</p>
                <p><strong>👥 Mediador:</strong> A definir</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Experiências de reparações no Caribe e Colômbia, apresentando modelos e estratégias que podem ser aplicados no contexto brasileiro.</p>
            </div>
        </div>

        <div class="seminario-painel-item">
            <h3>Panafricanismo e a luta pró-reparações em Angola, Moçambique e São Tomé e Príncipe</h3>
            <div class="seminario-painel-info">
                <p><strong>📅 Data:</strong> 12/11/2025</p>
                <p><strong>🕒 Horário:</strong> 13:20 às 16:00</p>
                <p><strong>📍 Local:</strong> Auditório da Faculdade de Engenharia da UFMG</p>
                <p><strong>🎤 Palestrantes:</strong> Elizabeth Cruz, Paulo Gamba, Conceição Queiroz, Maria das Neves</p>
                <p><strong>👥 Mediador:</strong> A definir</p>
            </div>
            <div class="seminario-painel-descricao">
                <p>Experiências africanas de reparações e panafricanismo, trazendo perspectivas dos países lusófonos sobre políticas de reparação histórica.</p>
            </div>
        </div>
    </div>
    
    <div style="background: #2271b1; color: white; border-radius: 8px; padding: 20px; margin-top: 40px; text-align: center;">
        <h3 style="margin-top: 0;">📊 Funcionalidades no WordPress</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; text-align: left;">
            <div>
                <strong>✅ Painel Admin:</strong><br>
                • CRUD completo de painéis<br>
                • Upload de documentos<br>
                • Gestão de horários
            </div>
            <div>
                <strong>✅ Frontend:</strong><br>
                • Shortcode [seminario_paineis]<br>
                • Design responsivo<br>
                • Filtros por data/tema
            </div>
            <div>
                <strong>✅ Integração:</strong><br>
                • Sistema de inscrições<br>
                • Relatórios automáticos<br>
                • Email marketing
            </div>
        </div>
    </div>
</div>