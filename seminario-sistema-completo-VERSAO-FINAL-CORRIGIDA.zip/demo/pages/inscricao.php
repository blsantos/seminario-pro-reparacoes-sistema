<?php
// Processar formulário se enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];
    $success = false;
    
    // Validar campos obrigatórios
    if (empty($_POST['nome'])) {
        $errors[] = 'Nome é obrigatório';
    }
    
    if (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email válido é obrigatório';
    }
    
    // Validar painéis escolhidos
    $paineis_escolhidos = isset($_POST['paineis_escolhidos']) ? $_POST['paineis_escolhidos'] : [];
    
    // Se não há erros, simular sucesso
    if (empty($errors)) {
        $success = true;
        // Aqui salvaria no banco de dados
        file_put_contents('data/inscricoes.txt', 
            date('Y-m-d H:i:s') . " - " . $_POST['nome'] . " - " . $_POST['email'] . " - Painéis: " . implode(',', $paineis_escolhidos) . "\n", 
            FILE_APPEND
        );
    }
}
?>

<div class="seminario-inscricao-form">
    <h2>🧪 Teste o Formulário de Inscrição</h2>
    
    <?php if (isset($success) && $success): ?>
        <div style="background: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
            ✅ <strong>Inscrição realizada com sucesso!</strong><br>
            <small>No WordPress real, seria enviado email de confirmação automático.</small>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($errors)): ?>
        <div style="background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
            <strong>Erros encontrados:</strong>
            <ul style="margin: 10px 0 0 20px;">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="post">
        <div class="seminario-form-row">
            <div class="seminario-form-group">
                <label for="nome">Nome Completo *</label>
                <input type="text" id="nome" name="nome" required value="<?php echo isset($_POST['nome']) ? htmlspecialchars($_POST['nome']) : ''; ?>">
            </div>
            <div class="seminario-form-group">
                <label for="email">Email *</label>
                <input type="email" id="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
        </div>
        
        <div class="seminario-form-row">
            <div class="seminario-form-group">
                <label for="telefone">Telefone</label>
                <input type="tel" id="telefone" name="telefone" placeholder="(11) 99999-9999" value="<?php echo isset($_POST['telefone']) ? htmlspecialchars($_POST['telefone']) : ''; ?>">
            </div>
            <div class="seminario-form-group">
                <label for="pais">País</label>
                <input type="text" id="pais" name="pais" value="<?php echo isset($_POST['pais']) ? htmlspecialchars($_POST['pais']) : ''; ?>">
            </div>
        </div>
        
        <div class="seminario-form-row">
            <div class="seminario-form-group">
                <label for="cidade">Cidade</label>
                <input type="text" id="cidade" name="cidade" value="<?php echo isset($_POST['cidade']) ? htmlspecialchars($_POST['cidade']) : ''; ?>">
            </div>
            <div class="seminario-form-group">
                <label for="instituicao">Instituição</label>
                <input type="text" id="instituicao" name="instituicao" value="<?php echo isset($_POST['instituicao']) ? htmlspecialchars($_POST['instituicao']) : ''; ?>">
            </div>
        </div>
        
        <div class="seminario-form-group">
            <label for="cargo">Cargo/Função</label>
            <input type="text" id="cargo" name="cargo" value="<?php echo isset($_POST['cargo']) ? htmlspecialchars($_POST['cargo']) : ''; ?>">
        </div>
        
        <div class="seminario-form-group">
            <label for="area_interesse">Área de Interesse</label>
            <textarea id="area_interesse" name="area_interesse" rows="3"><?php echo isset($_POST['area_interesse']) ? htmlspecialchars($_POST['area_interesse']) : ''; ?></textarea>
        </div>
        
        <div class="seminario-form-group">
            <label>Painéis de Interesse (selecione quantos desejar)</label>
            <div class="seminario-paineis-checkbox">
                <?php 
                $paineis = [
                    1 => 'Reparações e justiça fiscal - 10/11 às 15:00',
                    2 => 'Contexto internacional hostil - 11/11 às 09:30', 
                    3 => 'Soberania digital e racismo cibernético - 11/11 às 13:30',
                    4 => 'Oligarquias e democracia eleitoral - 11/11 às 16:00',
                    5 => 'Panafricanismo no Caribe e Colômbia - 12/11 às 09:30',
                    6 => 'Panafricanismo em Angola, Moçambique e São Tomé - 12/11 às 13:20'
                ];
                
                $selecionados = isset($_POST['paineis_escolhidos']) ? $_POST['paineis_escolhidos'] : [];
                
                foreach ($paineis as $id => $titulo): ?>
                    <label class="seminario-checkbox-label">
                        <input type="checkbox" name="paineis_escolhidos[]" value="<?php echo $id; ?>" 
                               <?php echo in_array($id, $selecionados) ? 'checked' : ''; ?>>
                        <strong><?php echo htmlspecialchars($titulo); ?></strong>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="seminario-form-group">
            <label for="necessidades_especiais">Necessidades Especiais</label>
            <textarea id="necessidades_especiais" name="necessidades_especiais" rows="3" 
                      placeholder="Descreva qualquer necessidade especial para sua participação no evento"><?php echo isset($_POST['necessidades_especiais']) ? htmlspecialchars($_POST['necessidades_especiais']) : ''; ?></textarea>
        </div>
        
        <div class="seminario-form-submit">
            <button type="submit">✅ Enviar Inscrição (TESTE)</button>
        </div>
    </form>
    
    <div style="background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; padding: 15px; border-radius: 4px; margin-top: 30px;">
        <strong>💡 Funcionalidades do WordPress:</strong><br>
        • No WordPress real: dados salvos no banco MySQL/PostgreSQL<br>
        • Email de confirmação automático<br>
        • AJAX sem recarregar página<br>
        • Validação avançada com nonces de segurança<br>
        • Dashboard administrativo para gerenciar inscrições
    </div>
</div>

<script>
// Máscara para telefone (igual ao plugin real)
document.getElementById('telefone').addEventListener('input', function() {
    let value = this.value.replace(/\D/g, '');
    let formattedValue = '';
    
    if (value.length > 0) {
        if (value.length <= 2) {
            formattedValue = '(' + value;
        } else if (value.length <= 7) {
            formattedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2);
        } else {
            formattedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2, 7) + '-' + value.substring(7, 11);
        }
    }
    
    this.value = formattedValue;
});

// Sem limitação de painéis - pode selecionar quantos desejar
// Este comportamento permite máxima flexibilidade para os participantes
</script>