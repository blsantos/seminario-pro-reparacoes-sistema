<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - II Seminário Internacional Pró-Reparações</title>
    <link rel="stylesheet" href="../assets/seminario-modern.css">
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .wp-admin-bar { display: none; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            background: #f1f1f1;
            margin: 0;
            padding: 0;
        }
        
        /* WordPress Admin Header */
        .admin-header {
            background: #23282d;
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 1px 3px rgba(0,0,0,0.3);
        }
        
        .admin-header h1 {
            margin: 0;
            font-size: 18px;
            font-weight: 400;
        }
        
        .admin-header .user-info {
            font-size: 13px;
            color: #ccc;
        }
        
        /* Admin Sidebar */
        .admin-layout {
            display: flex;
            min-height: calc(100vh - 60px);
        }
        
        .admin-sidebar {
            background: #23282d;
            width: 200px;
            min-height: 100%;
        }
        
        .admin-menu {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        .admin-menu li {
            border-bottom: 1px solid #32373c;
        }
        
        .admin-menu a {
            display: block;
            color: #ccc;
            padding: 12px 15px;
            text-decoration: none;
            font-size: 13px;
            transition: all 0.2s;
        }
        
        .admin-menu a:hover, .admin-menu a.active {
            background: #0073aa;
            color: white;
        }
        
        .admin-menu .menu-icon {
            margin-right: 8px;
            font-size: 16px;
        }
        
        /* Main Content */
        .admin-content {
            flex: 1;
            padding: 20px;
            background: #f1f1f1;
        }
        
        .page-title {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 4px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .page-title h1 {
            margin: 0;
            color: #23282d;
            font-size: 24px;
            font-weight: 600;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            text-align: center;
            border-left: 4px solid #0073aa;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #23282d;
            margin: 10px 0;
        }
        
        .stat-label {
            color: #666;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Data Tables */
        .admin-table {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .table-header {
            background: #f8f9fa;
            padding: 15px 20px;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table-header h3 {
            margin: 0;
            color: #23282d;
            font-size: 16px;
        }
        
        .btn {
            background: #0073aa;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            font-size: 13px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn:hover {
            background: #005a87;
        }
        
        .btn-secondary {
            background: #6c757d;
        }
        
        .btn-secondary:hover {
            background: #545b62;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table th,
        table td {
            padding: 12px 20px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        
        table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
            font-size: 13px;
        }
        
        table td {
            font-size: 14px;
            color: #495057;
        }
        
        .participant-photo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #dee2e6;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .status-confirmado {
            background: #d4edda;
            color: #155724;
        }
        
        .status-pendente {
            background: #fff3cd;
            color: #856404;
        }
        
        .action-links a {
            color: #0073aa;
            text-decoration: none;
            margin-right: 10px;
            font-size: 13px;
        }
        
        .action-links a:hover {
            text-decoration: underline;
        }
        
        /* Active menu highlighting */
        .admin-content[data-page="dashboard"] .menu-dashboard,
        .admin-content[data-page="conferencistas"] .menu-conferencistas,
        .admin-content[data-page="paineis"] .menu-paineis,
        .admin-content[data-page="observadores"] .menu-observadores,
        .admin-content[data-page="inscricoes"] .menu-inscricoes {
            background: #0073aa !important;
            color: white !important;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>🎯 Seminário Pró-Reparações - Painel Administrativo</h1>
        <div class="user-info">
            Usuário: Admin | <a href="../demo/" style="color: #ccc;">Ver Site</a>
        </div>
    </div>
    
    <div class="admin-layout">
        <div class="admin-sidebar">
            <ul class="admin-menu">
                <li><a href="?page=dashboard" class="menu-dashboard"><span class="menu-icon">📊</span>Dashboard</a></li>
                <li><a href="?page=conferencistas" class="menu-conferencistas"><span class="menu-icon">🎤</span>Conferencistas</a></li>
                <li><a href="?page=paineis" class="menu-paineis"><span class="menu-icon">🎯</span>Painéis Temáticos</a></li>
                <li><a href="?page=observadores" class="menu-observadores"><span class="menu-icon">👁️</span>Observadores</a></li>
                <li><a href="?page=inscricoes" class="menu-inscricoes"><span class="menu-icon">📝</span>Inscrições</a></li>
                <li><a href="?page=relatorios" class="menu-relatorios"><span class="menu-icon">📈</span>Relatórios</a></li>
                <li><a href="?page=configuracoes" class="menu-configuracoes"><span class="menu-icon">⚙️</span>Configurações</a></li>
            </ul>
        </div>
        
        <div class="admin-content" data-page="<?php echo $_GET['page'] ?? 'dashboard'; ?>">
            <?php
            $page = $_GET['page'] ?? 'dashboard';
            
            switch($page) {
                case 'dashboard':
                    include 'admin/dashboard.php';
                    break;
                case 'conferencistas':
                    include 'admin/conferencistas.php';
                    break;
                case 'paineis':
                    include 'admin/paineis.php';
                    break;
                case 'observadores':
                    include 'admin/observadores.php';
                    break;
                case 'inscricoes':
                    include 'admin/inscricoes.php';
                    break;
                case 'relatorios':
                    include 'admin/relatorios.php';
                    break;
                case 'configuracoes':
                    include 'admin/configuracoes.php';
                    break;
                default:
                    include 'admin/dashboard.php';
            }
            ?>
        </div>
    </div>
    
    <script src="../assets/script.js"></script>
    <script>
        // Highlight active menu item
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = new URLSearchParams(window.location.search).get('page') || 'dashboard';
            const menuLinks = document.querySelectorAll('.admin-menu a');
            
            menuLinks.forEach(link => {
                link.classList.remove('active');
                if (link.href.includes('page=' + currentPage)) {
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>