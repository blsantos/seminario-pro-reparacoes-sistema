<?php
// Página de gerenciamento de observadores
?>
<div class="page-title">
    <h1>👁️ Gerenciar Observadores Internacionais</h1>
</div>

<div class="admin-table">
    <div class="table-header">
        <h3>Observadores Confirmados (15)</h3>
        <div>
            <a href="#" class="btn">➕ Adicionar Novo</a>
            <a href="#" class="btn btn-secondary">📊 Exportar Lista</a>
        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>Instituição/Cargo</th>
                <th>País</th>
                <th>Especialidade</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><img src="../assets/imgs/image_1759068229695.png" class="participant-photo" alt="Angela Davis"></td>
                <td><strong>Angela Davis</strong></td>
                <td>Professora Emérita<br><small>Universidade da Califórnia</small></td>
                <td>🇺🇸 Estados Unidos</td>
                <td>Filosofia Política, Abolicionismo</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Perfil</a>
                    <a href="#">Contato</a>
                </td>
            </tr>
            <tr>
                <td><img src="../assets/imgs/image_1759068327295.png" class="participant-photo" alt="Frederico Pita"></td>
                <td><strong>Frederico Pita</strong></td>
                <td>Representante CLACSO<br><small>Conselho Latino-Americano de Ciências Sociais</small></td>
                <td>🇦🇷 Argentina</td>
                <td>Ciências Sociais, Movimento Afro-latino</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Perfil</a>
                    <a href="#">Contato</a>
                </td>
            </tr>
            <tr>
                <td><div style="width: 40px; height: 40px; background: #ddd; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">SEM<br>FOTO</div></td>
                <td><strong>Nilma Lino Gomes</strong></td>
                <td>Ex-Ministra da Igualdade Racial<br><small>Universidade Federal de Minas Gerais</small></td>
                <td>🇧🇷 Brasil</td>
                <td>Educação, Relações Étnico-raciais</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Perfil</a>
                    <a href="#">Contato</a>
                </td>
            </tr>
            <tr>
                <td><div style="width: 40px; height: 40px; background: #ddd; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">SEM<br>FOTO</div></td>
                <td><strong>Conceição Evaristo</strong></td>
                <td>Escritora e Pesquisadora<br><small>Literatura Afro-brasileira</small></td>
                <td>🇧🇷 Brasil</td>
                <td>Literatura, Cultura Afro-brasileira</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Perfil</a>
                    <a href="#">Contato</a>
                </td>
            </tr>
            <tr>
                <td><div style="width: 40px; height: 40px; background: #ddd; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">SEM<br>FOTO</div></td>
                <td><strong>Achille Mbembe</strong></td>
                <td>Filósofo e Teórico Político<br><small>Universidade de Witwatersrand</small></td>
                <td>🇿🇦 África do Sul</td>
                <td>Filosofia Política, Pós-colonialismo</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Perfil</a>
                    <a href="#">Contato</a>
                </td>
            </tr>
            <tr>
                <td><div style="width: 40px; height: 40px; background: #ddd; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">SEM<br>FOTO</div></td>
                <td><strong>Mamadou Diouf</strong></td>
                <td>Professor de História Africana<br><small>Universidade Columbia</small></td>
                <td>🇺🇸 Estados Unidos</td>
                <td>História Africana, Diáspora</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Perfil</a>
                    <a href="#">Contato</a>
                </td>
            </tr>
            <tr>
                <td><div style="width: 40px; height: 40px; background: #ddd; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">SEM<br>FOTO</div></td>
                <td><strong>Éloi Ficquet</strong></td>
                <td>Professor de Estudos Africanos<br><small>École des Hautes Études en Sciences Sociales</small></td>
                <td>🇫🇷 França</td>
                <td>Estudos Africanos, Antropologia</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Perfil</a>
                    <a href="#">Contato</a>
                </td>
            </tr>
            <tr>
                <td colspan="7" style="text-align: center; padding: 20px; color: #666;">
                    <em>+ 8 outros observadores confirmados...</em><br>
                    <small>Total: 15 observadores de 8 países diferentes</small>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
    <div class="admin-table">
        <div class="table-header">
            <h3>🌍 Distribuição por País</h3>
        </div>
        <table>
            <tbody>
                <tr><td>🇧🇷 Brasil</td><td>6 observadores</td></tr>
                <tr><td>🇺🇸 Estados Unidos</td><td>3 observadores</td></tr>
                <tr><td>🇫🇷 França</td><td>2 observadores</td></tr>
                <tr><td>🇵🇹 Portugal</td><td>1 observador</td></tr>
                <tr><td>🇪🇸 Espanha</td><td>1 observador</td></tr>
                <tr><td>🇿🇦 África do Sul</td><td>1 observador</td></tr>
                <tr><td>🇦🇷 Argentina</td><td>1 observador</td></tr>
            </tbody>
        </table>
    </div>
    
    <div class="admin-table">
        <div class="table-header">
            <h3>📚 Áreas de Especialidade</h3>
        </div>
        <table>
            <tbody>
                <tr><td>Filosofia Política</td><td>4</td></tr>
                <tr><td>História Africana</td><td>3</td></tr>
                <tr><td>Literatura Afro-brasileira</td><td>2</td></tr>
                <tr><td>Ciências Sociais</td><td>2</td></tr>
                <tr><td>Educação</td><td>2</td></tr>
                <tr><td>Direitos Humanos</td><td>2</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div style="background: #e7f3ff; border: 1px solid #bee5eb; border-radius: 8px; padding: 20px; margin-top: 20px;">
    <h3 style="color: #0c5460; margin-top: 0;">ℹ️ Sobre os Observadores</h3>
    <p style="color: #0c5460;">
        Os observadores internacionais são acadêmicos renomados e especialistas em reparações históricas, 
        panafricanismo e direitos humanos. Eles participam do seminário como convidados especiais para 
        compartilhar experiências internacionais e contribuir com o debate sobre reparações.
    </p>
    <p style="color: #0c5460; margin-bottom: 0;">
        <strong>🎯 Função:</strong> Observar e contribuir com perspectivas internacionais sobre reparações históricas
    </p>
</div>