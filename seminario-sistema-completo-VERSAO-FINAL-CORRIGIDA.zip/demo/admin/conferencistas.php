<?php
// Página de gerenciamento de conferencistas
?>
<div class="page-title">
    <h1>🎤 Gerenciar Conferencistas</h1>
</div>

<div class="admin-table">
    <div class="table-header">
        <h3>Conferencistas Confirmados (22)</h3>
        <div>
            <a href="#" class="btn">➕ Adicionar Novo</a>
            <a href="#" class="btn btn-secondary">📊 Exportar Lista</a>
        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>Cargo/Instituição</th>
                <th>País</th>
                <th>Painel</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><img src="../assets/imgs/image_1759046662766.png" class="participant-photo" alt="Anielle Franco"></td>
                <td><strong>Anielle Franco</strong></td>
                <td>Ministra da Igualdade Racial<br><small>Ministério da Igualdade Racial</small></td>
                <td>🇧🇷 Brasil</td>
                <td>Estatuto da Igualdade Racial - MG</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td><img src="../assets/imgs/image_1759046690819.png" class="participant-photo" alt="Macaé Evaristo"></td>
                <td><strong>Macaé Evaristo</strong></td>
                <td>Ministra dos Direitos Humanos<br><small>Ministério dos Direitos Humanos</small></td>
                <td>🇧🇷 Brasil</td>
                <td>Estatuto da Igualdade Racial - MG</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td><img src="../assets/imgs/image_1759046717057.png" class="participant-photo" alt="Mireille Fanon Mendès-France"></td>
                <td><strong>Mireille Fanon Mendès-France</strong></td>
                <td>Co-presidenta<br><small>Fundação Frantz Fanon</small></td>
                <td>🇫🇷 França</td>
                <td>Contexto internacional hostil</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td><img src="../assets/imgs/image_1759046741469.png" class="participant-photo" alt="Ndongo Samba Sylla"></td>
                <td><strong>Ndongo Samba Sylla</strong></td>
                <td>Economista e Pesquisador<br><small>IDEAS/África</small></td>
                <td>🇸🇳 Senegal</td>
                <td>Reparações e justiça fiscal</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td><img src="../assets/imgs/image_1759046767615.png" class="participant-photo" alt="Carlos Rosero"></td>
                <td><strong>Carlos Rosero</strong></td>
                <td>Ministro da Igualdade<br><small>República da Colômbia</small></td>
                <td>🇨🇴 Colômbia</td>
                <td>Panafricanismo Caribe/Colômbia</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td><img src="../assets/imgs/image_1759046793175.png" class="participant-photo" alt="José Lingna Nafafé"></td>
                <td><strong>José Lingna Nafafé</strong></td>
                <td>Professor e Investigador<br><small>Universidade de Londres</small></td>
                <td>🇬🇧 Reino Unido</td>
                <td>Reparações e justiça fiscal</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td><img src="../assets/imgs/image_1759046828818.png" class="participant-photo" alt="Angela Davis"></td>
                <td><strong>Angela Davis</strong></td>
                <td>Filósofa e Ativista<br><small>Universidade da Califórnia</small></td>
                <td>🇺🇸 Estados Unidos</td>
                <td>Panafricanismo e Resistência</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td><div style="width: 40px; height: 40px; background: #ddd; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">SEM<br>FOTO</div></td>
                <td><strong>Sueli Carneiro</strong></td>
                <td>Filósofa e Escritora<br><small>Instituto Geledés</small></td>
                <td>🇧🇷 Brasil</td>
                <td>Feminismo Negro e Reparações</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Editar</a>
                    <a href="#">Ver Bio</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td colspan="7" style="text-align: center; padding: 20px; color: #666;">
                    <em>+ 14 outros conferencistas confirmados...</em><br>
                    <small>Use os filtros acima para ver todos os participantes</small>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<div style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 8px; padding: 20px; margin-top: 20px;">
    <h3 style="color: #856404; margin-top: 0;">💡 Recursos Disponíveis</h3>
    <div style="color: #856404;">
        <p><strong>✅ Funcionalidades Ativas:</strong></p>
        <ul>
            <li>Upload de fotos dos conferencistas</li>
            <li>Editor de biografias com rich-text</li>
            <li>Vinculação automática com painéis temáticos</li>
            <li>Sistema de notificações por email</li>
            <li>Exportação de dados em CSV/PDF</li>
            <li>Controle de status (confirmado/pendente/cancelado)</li>
        </ul>
    </div>
</div>