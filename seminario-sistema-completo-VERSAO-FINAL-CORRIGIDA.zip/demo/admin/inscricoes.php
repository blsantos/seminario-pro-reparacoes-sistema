<?php
// Página de gerenciamento de inscrições
?>
<div class="page-title">
    <h1>📝 Gerenciar Inscrições</h1>
</div>

<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); margin-bottom: 30px;">
    <div class="stat-card" style="border-left-color: #28a745;">
        <div class="stat-number">147</div>
        <div class="stat-label">Total de Inscrições</div>
    </div>
    
    <div class="stat-card" style="border-left-color: #17a2b8;">
        <div class="stat-number">142</div>
        <div class="stat-label">Confirmadas</div>
    </div>
    
    <div class="stat-card" style="border-left-color: #ffc107;">
        <div class="stat-number">5</div>
        <div class="stat-label">Pendentes</div>
    </div>
    
    <div class="stat-card" style="border-left-color: #dc3545;">
        <div class="stat-number">0</div>
        <div class="stat-label">Canceladas</div>
    </div>
</div>

<div class="admin-table">
    <div class="table-header">
        <h3>Inscrições Recentes</h3>
        <div>
            <a href="#" class="btn">📧 Enviar Email em Massa</a>
            <a href="#" class="btn btn-secondary">📊 Exportar Lista</a>
        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>Data</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Categoria</th>
                <th>Instituição</th>
                <th>Painéis de Interesse</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>27/09/2025</td>
                <td><strong>Maria Silva Santos</strong></td>
                <td>maria.silva@ufmg.br</td>
                <td>👩‍🎓 Estudante</td>
                <td>UFMG - Direito</td>
                <td>Reparações e justiça fiscal, Estatuto da Igualdade Racial</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Ver</a>
                    <a href="#">Editar</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td>27/09/2025</td>
                <td><strong>João Carlos Oliveira</strong></td>
                <td>joao.carlos@pucminas.br</td>
                <td>👨‍🏫 Professor</td>
                <td>PUC Minas - História</td>
                <td>Panafricanismo, Contexto internacional hostil</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Ver</a>
                    <a href="#">Editar</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td>26/09/2025</td>
                <td><strong>Ana Paula Rodrigues</strong></td>
                <td>ana.rodrigues@gmail.com</td>
                <td>👩‍⚖️ Advogada</td>
                <td>OAB-MG</td>
                <td>Estatuto da Igualdade Racial, Reparações e justiça fiscal</td>
                <td><span class="status-badge status-pendente">Pendente</span></td>
                <td class="action-links">
                    <a href="#">Ver</a>
                    <a href="#">Aprovar</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td>26/09/2025</td>
                <td><strong>Carlos Eduardo Lima</strong></td>
                <td>carlos.lima@usp.br</td>
                <td>👨‍💼 Pesquisador</td>
                <td>USP - Sociologia</td>
                <td>Panafricanismo Angola/Moçambique</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Ver</a>
                    <a href="#">Editar</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td>25/09/2025</td>
                <td><strong>Mariana Costa Ferreira</strong></td>
                <td>mariana.costa@ufba.br</td>
                <td>👩‍🎓 Estudante</td>
                <td>UFBA - Antropologia</td>
                <td>Luta pró-reparações Portugal/Espanha</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Ver</a>
                    <a href="#">Editar</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td>25/09/2025</td>
                <td><strong>Rafael Santos Pereira</strong></td>
                <td>rafael.pereira@outlook.com</td>
                <td>👨‍💻 Ativista</td>
                <td>Movimento Negro Unificado</td>
                <td>Contexto internacional hostil, Panafricanismo</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
                <td class="action-links">
                    <a href="#">Ver</a>
                    <a href="#">Editar</a>
                    <a href="#">Email</a>
                </td>
            </tr>
            <tr>
                <td colspan="8" style="text-align: center; padding: 20px; color: #666;">
                    <em>Mostrando as 6 inscrições mais recentes de 147 total</em><br>
                    <small><a href="#" style="color: #0073aa;">Ver todas as inscrições →</a></small>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
    <div class="admin-table">
        <div class="table-header">
            <h3>📊 Por Categoria Profissional</h3>
        </div>
        <table>
            <tbody>
                <tr><td>👨‍🎓 Estudantes</td><td>67 (45.6%)</td></tr>
                <tr><td>👩‍🏫 Professores</td><td>32 (21.8%)</td></tr>
                <tr><td>👨‍💼 Pesquisadores</td><td>24 (16.3%)</td></tr>
                <tr><td>👩‍⚖️ Advogados</td><td>13 (8.8%)</td></tr>
                <tr><td>👨‍💻 Ativistas</td><td>11 (7.5%)</td></tr>
            </tbody>
        </table>
    </div>
    
    <div class="admin-table">
        <div class="table-header">
            <h3>🎯 Painéis Mais Procurados</h3>
        </div>
        <table>
            <tbody>
                <tr><td>Reparações e justiça fiscal</td><td>89 interessados</td></tr>
                <tr><td>Estatuto da Igualdade Racial - MG</td><td>76 interessados</td></tr>
                <tr><td>Contexto internacional hostil</td><td>65 interessados</td></tr>
                <tr><td>Panafricanismo Caribe/Colômbia</td><td>58 interessados</td></tr>
                <tr><td>Panafricanismo Angola/Moçambique</td><td>52 interessados</td></tr>
                <tr><td>Luta pró-reparações Portugal/Espanha</td><td>43 interessados</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div style="background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 8px; padding: 20px; margin-top: 20px;">
    <h3 style="color: #0c5460; margin-top: 0;">📋 Formulário de Inscrição Ativo</h3>
    <p style="color: #0c5460;">
        <strong>Status:</strong> ✅ Aberto para novas inscrições<br>
        <strong>Campos obrigatórios:</strong> Nome, email, categoria profissional, instituição<br>
        <strong>Validação automática:</strong> Email único, formato válido<br>
        <strong>Notificações:</strong> Email de confirmação automático
    </p>
    <p style="color: #0c5460; margin-bottom: 0;">
        <strong>📧 Últimos emails enviados:</strong> 147 confirmações, 5 lembretes de documentação pendente
    </p>
</div>