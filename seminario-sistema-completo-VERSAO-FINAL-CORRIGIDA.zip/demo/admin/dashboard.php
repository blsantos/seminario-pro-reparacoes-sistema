<?php
// Dashboard principal
?>
<div class="page-title">
    <h1>📊 Dashboard - Visão Geral do Seminário</h1>
</div>

<div class="stats-grid">
    <div class="stat-card" style="border-left-color: #28a745;">
        <div class="stat-number">22</div>
        <div class="stat-label">Conferencistas Confirmados</div>
    </div>
    
    <div class="stat-card" style="border-left-color: #17a2b8;">
        <div class="stat-number">15</div>
        <div class="stat-label">Observadores Internacionais</div>
    </div>
    
    <div class="stat-card" style="border-left-color: #ffc107;">
        <div class="stat-number">6</div>
        <div class="stat-label">Painéis Temáticos</div>
    </div>
    
    <div class="stat-card" style="border-left-color: #dc3545;">
        <div class="stat-number">147</div>
        <div class="stat-label">Inscrições Recebidas</div>
    </div>
</div>

<div class="admin-table">
    <div class="table-header">
        <h3>📅 Próximos Eventos</h3>
        <a href="?page=paineis" class="btn">Ver Todos os Painéis</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Data/Hora</th>
                <th>Painel</th>
                <th>Local</th>
                <th>Palestrantes</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><strong>10/11/2025</strong><br>13:20 - 14:50</td>
                <td>Estatuto da Igualdade Racial - MG</td>
                <td>Assembleia Legislativa - MG</td>
                <td>Anielle Franco, Macaé Evaristo</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
            </tr>
            <tr>
                <td><strong>10/11/2025</strong><br>15:00 - 17:30</td>
                <td>Reparações e justiça fiscal</td>
                <td>Assembleia Legislativa - MG</td>
                <td>Ndongo Samba Sylla, José Lingna Nafafé</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
            </tr>
            <tr>
                <td><strong>11/11/2025</strong><br>09:30 - 12:00</td>
                <td>Contexto internacional hostil</td>
                <td>Assembleia Legislativa - MG</td>
                <td>Mireille Fanon Mendès-France</td>
                <td><span class="status-badge status-confirmado">Confirmado</span></td>
            </tr>
        </tbody>
    </table>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="admin-table">
        <div class="table-header">
            <h3>🌍 Distribuição por País</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>País</th>
                    <th>Participantes</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>🇧🇷 Brasil</td><td>15</td></tr>
                <tr><td>🇫🇷 França</td><td>3</td></tr>
                <tr><td>🇵🇹 Portugal</td><td>2</td></tr>
                <tr><td>🇨🇴 Colômbia</td><td>2</td></tr>
                <tr><td>🇦🇴 Angola</td><td>2</td></tr>
                <tr><td>🇲🇿 Moçambique</td><td>2</td></tr>
                <tr><td>🇺🇸 Estados Unidos</td><td>2</td></tr>
                <tr><td>🇸🇳 Senegal</td><td>1</td></tr>
                <tr><td>🇿🇦 África do Sul</td><td>1</td></tr>
                <tr><td>🇦🇷 Argentina</td><td>1</td></tr>
                <tr><td>🇬🇧 Reino Unido</td><td>1</td></tr>
                <tr><td>🇪🇸 Espanha</td><td>1</td></tr>
            </tbody>
        </table>
    </div>
    
    <div class="admin-table">
        <div class="table-header">
            <h3>📈 Estatísticas de Inscrições</h3>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Categoria</th>
                    <th>Quantidade</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>👨‍🎓 Estudantes</td><td>67</td></tr>
                <tr><td>👩‍🏫 Professores</td><td>32</td></tr>
                <tr><td>👨‍💼 Pesquisadores</td><td>24</td></tr>
                <tr><td>👩‍⚖️ Advogados</td><td>13</td></tr>
                <tr><td>👨‍💻 Ativistas</td><td>11</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div style="background: #e7f3ff; border: 1px solid #bee5eb; border-radius: 8px; padding: 20px; margin-top: 30px;">
    <h3 style="color: #0c5460; margin-top: 0;">ℹ️ Informações do Sistema</h3>
    <p style="color: #0c5460; margin-bottom: 0;">
        <strong>Plugin WordPress:</strong> Seminário Sistema Completo v6.0<br>
        <strong>Banco de Dados:</strong> 5 tabelas ativas com dados reais<br>
        <strong>Última Sincronização:</strong> <?php echo date('d/m/Y H:i:s'); ?><br>
        <strong>Status:</strong> ✅ Sistema funcionando normalmente
    </p>
</div>