<?php
// Página de configurações
?>
<div class="page-title">
    <h1>⚙️ Configurações do Sistema</h1>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="admin-table">
        <div class="table-header">
            <h3>🎯 Informações do Evento</h3>
        </div>
        <div style="padding: 20px;">
            <form>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Nome do Evento:</label>
                    <input type="text" value="II Seminário Internacional Pró-Reparações" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Subtítulo:</label>
                    <input type="text" value="Um Projeto de Nação" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Data de Início:</label>
                    <input type="date" value="2025-11-10" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Data de Término:</label>
                    <input type="date" value="2025-11-14" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Local:</label>
                    <input type="text" value="Belo Horizonte - MG" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <button type="submit" class="btn">Salvar Alterações</button>
            </form>
        </div>
    </div>
    
    <div class="admin-table">
        <div class="table-header">
            <h3>📧 Configurações de Email</h3>
        </div>
        <div style="padding: 20px;">
            <form>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Email do Sistema:</label>
                    <input type="email" value="contato@reparacoeshistoricas.org" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Nome do Remetente:</label>
                    <input type="text" value="Seminário Pró-Reparações" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">
                        <input type="checkbox" checked> Enviar email de confirmação automática
                    </label>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">
                        <input type="checkbox" checked> Notificar admin sobre novas inscrições
                    </label>
                </div>
                
                <button type="submit" class="btn">Salvar Configurações</button>
            </form>
        </div>
    </div>
</div>

<div class="admin-table" style="margin-top: 20px;">
    <div class="table-header">
        <h3>💾 Configurações do Plugin</h3>
    </div>
    <div style="padding: 20px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
            <div>
                <h4>🔧 Funcionalidades Ativas</h4>
                <div style="margin-bottom: 10px;">
                    <label style="display: block;">
                        <input type="checkbox" checked> Formulário de Inscrição
                    </label>
                </div>
                <div style="margin-bottom: 10px;">
                    <label style="display: block;">
                        <input type="checkbox" checked> Gestão de Conferencistas
                    </label>
                </div>
                <div style="margin-bottom: 10px;">
                    <label style="display: block;">
                        <input type="checkbox" checked> Gestão de Observadores
                    </label>
                </div>
                <div style="margin-bottom: 10px;">
                    <label style="display: block;">
                        <input type="checkbox" checked> Painéis Temáticos
                    </label>
                </div>
                <div style="margin-bottom: 10px;">
                    <label style="display: block;">
                        <input type="checkbox" checked> Sistema de Relatórios
                    </label>
                </div>
            </div>
            
            <div>
                <h4>🎨 Personalização</h4>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Cor Principal:</label>
                    <input type="color" value="#FF6B35" style="width: 60px; height: 40px; border: none; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Cor Secundária:</label>
                    <input type="color" value="#D63031" style="width: 60px; height: 40px; border: none; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">
                        <input type="checkbox" checked> Tema Afro-brasileiro
                    </label>
                </div>
            </div>
        </div>
        
        <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
            <button class="btn">Salvar Todas as Configurações</button>
            <a href="#" class="btn btn-secondary" style="margin-left: 10px;">Restaurar Padrões</a>
        </div>
    </div>
</div>

<div class="admin-table" style="margin-top: 20px;">
    <div class="table-header">
        <h3>📊 Informações do Sistema</h3>
    </div>
    <div style="padding: 20px;">
        <table style="width: 100%;">
            <tbody>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Versão do Plugin:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;">6.0 - Sistema Completo</td>
                </tr>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>WordPress:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;">6.8.2 (compatível)</td>
                </tr>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>PHP:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;">8.2+ (recomendado)</td>
                </tr>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Banco de Dados:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;">MySQL/PostgreSQL</td>
                </tr>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Tabelas Criadas:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;">5 tabelas ativas</td>
                </tr>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Última Atualização:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo date('d/m/Y H:i:s'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>