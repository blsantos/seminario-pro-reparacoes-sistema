jQuery(document).ready(function($) {
    
    // Formulário de inscrição
    $('#seminario-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var submitBtn = $('#seminario-submit-btn');
        var messageDiv = $('#seminario-message');
        
        // Validar painéis selecionados
        var paineisSelecionados = $('input[name="paineis_escolhidos[]"]:checked').length;
        var limitePaineis = parseInt(seminarioAjax.limitePaineis) || 3;
        
        if (paineisSelecionados > limitePaineis) {
            messageDiv.removeClass('success').addClass('error').show();
            messageDiv.text('Você pode escolher no máximo ' + limitePaineis + ' painéis.');
            return;
        }
        
        // Desabilitar botão
        submitBtn.prop('disabled', true).text('Processando...');
        messageDiv.hide();
        
        // Preparar dados
        var formData = form.serialize();
        formData += '&action=seminario_submit_inscricao';
        formData += '&nonce=' + seminarioAjax.nonce;
        
        // Enviar via AJAX
        $.ajax({
            url: seminarioAjax.ajaxUrl,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass('error').addClass('success').show();
                    messageDiv.text(response.data);
                    form[0].reset();
                } else {
                    messageDiv.removeClass('success').addClass('error').show();
                    messageDiv.text(response.data || 'Erro ao processar inscrição');
                }
            },
            error: function() {
                messageDiv.removeClass('success').addClass('error').show();
                messageDiv.text('Erro de conexão. Tente novamente.');
            },
            complete: function() {
                submitBtn.prop('disabled', false).text('Enviar Inscrição');
            }
        });
    });
    
    // Limitar seleção de painéis
    $('input[name="paineis_escolhidos[]"]').on('change', function() {
        var limitePaineis = parseInt(seminarioAjax.limitePaineis) || 3;
        var selecionados = $('input[name="paineis_escolhidos[]"]:checked').length;
        
        if (selecionados >= limitePaineis) {
            $('input[name="paineis_escolhidos[]"]:not(:checked)').prop('disabled', true);
        } else {
            $('input[name="paineis_escolhidos[]"]').prop('disabled', false);
        }
    });
    
    // Modal para detalhes da inscrição (admin)
    window.viewInscricao = function(id) {
        var modal = $('#seminario-modal');
        var modalBody = $('#seminario-modal-body');
        
        modalBody.html('<p>Carregando...</p>');
        modal.show();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'seminario_get_inscricao_details',
                id: id,
                nonce: seminarioAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    modalBody.html(response.data);
                } else {
                    modalBody.html('<p>Erro ao carregar detalhes.</p>');
                }
            },
            error: function() {
                modalBody.html('<p>Erro de conexão.</p>');
            }
        });
    };
    
    // Fechar modal
    $('.seminario-modal-close, .seminario-modal').on('click', function(e) {
        if (e.target === this) {
            $('#seminario-modal').hide();
        }
    });
    
    // Máscara para telefone
    $('#telefone').on('input', function() {
        var value = this.value.replace(/\D/g, '');
        var formattedValue = '';
        
        if (value.length > 0) {
            if (value.length <= 2) {
                formattedValue = '(' + value;
            } else if (value.length <= 7) {
                formattedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2);
            } else {
                formattedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2, 7) + '-' + value.substring(7, 11);
            }
        }
        
        this.value = formattedValue;
    });
    
    // Auto-refresh das estatísticas (admin)
    if (typeof seminarioAdmin !== 'undefined' && seminarioAdmin.autoRefresh) {
        setInterval(function() {
            location.reload();
        }, 30000); // 30 segundos
    }
});
